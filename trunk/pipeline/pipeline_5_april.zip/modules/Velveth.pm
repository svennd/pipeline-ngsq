# Velveth.pm
# svenn dhert @ sckcen
#
# use :
# locally assemble the inserties
# using velveth

package Assembly::Velveth;

#use strict; - dynamicly making files, this will cry :P
use warnings;

our $VERSION = '1.00';
our @EXPORT  = qw(do_local_assembly);

sub do_local_assembly
{
	open (PEAK_RESULTS, "result/roi_inserties_couple") or die("1file not found");
	open (DESCRIPTION, ">result/velveth_descriptor") or die("2file not found");
	my @left_points;
	my @right_points;
	
	my $a = 0;
	my $i = 0;
	my $prev_name;
	while (my $current_line = <PEAK_RESULTS>)
	{
		if ($current_line =~ /^>> \.\/(.*?)\.mapped/)
		{
			# there is atleast 1 insertie found
			if (scalar(@left_points) >= 1)
			{
				get_mapped($prev_name, \@left_points, \@right_points);
			}
			$prev_name = $current_line;
		}
		else
		{
			(my $first, my $second) = split('\t', $current_line);
			chomp($first, $second);
				
			if ($first > $second)
			{
				$left_points[$i] = $second;
				$right_points[$i] = $first;
			}
			else
			{
				$left_points[$i] = $first;
				$right_points[$i] = $second;
			}
			$i++;
		}
	}
	# for last one we do it a last time
	if (scalar(@left_points) >= 1)
	{
		get_mapped($prev_name, \@left_points, \@right_points);
	}
}


sub get_mapped
{
	my ($file, $left_points, $right_points) = @_;
	my @left_points	 = @{$left_points};
	my @right_points = @{$right_points};
	
	my $alfa = (($file =~ m/\.\/(.*?)\.mapped$/)[0]);
	open(SAM_FILE, $alfa) or die ("file not found :)");
	open(RESULT, ">ROI_". $alfa) or die ("file not found :)");
	
	while (<SAM_FILE>)
	{
		my $current_line = $_;
		# split tabbed
		(
			my $qname, 
			my $flag,
			my $rname,
			my $pos,	
			my $mapq,	
			my $cigar,	
			my $NRNM,	
			my $mpos,
			my $size,
			my $SEQ
		) = split('\t', $current_line);	
		# dec flag to bin values
		(
			my $second_read,
			my $first_read,
			my $strand_mate, 	my $strand_quer,
			my $mate_unmapped,	my $quer_unmapped,
			my $proper_mapped,
			my $paired_seq
		) = split(//, dec2bin($flag));


		if ($proper_mapped == 0)
		{
			for(my $index = 0; $index < @left_points; $index++)
			{
				if (($pos > $left_points[$index]) && ($pos < $right_points[$index]))
				{
				#	print $pos. "\n";
					print RESULT $SEQ ."\n";
				}
			}
		}
	}
}

# Monsieurs Pieter - sckcen
sub dec2bin
{
     my $str = unpack("B32", pack("N", shift));
     $str =~ s/^0+(?=\d)//;   # otherwise you'll get leading zeros
     if (length($str) < 8) {
        $str = "0"x(8-length($str)).$str;
     }
     return $str;
}

