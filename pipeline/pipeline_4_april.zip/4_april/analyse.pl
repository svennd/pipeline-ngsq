#!/usr/bin/perl
# svenn dhert @ sckcen
# version 2.0

# default library's
use warnings;
use strict;
use POSIX;
use Getopt::Long;

# required modules
require "modules/Log.pm";
require "modules/GunZip.pm";
require "modules/FileFormat.pm";
require "modules/PipeLine.pm";
require "modules/SplitData.pm";
require "modules/Screen.pm";
require "modules/Config.pm";

# these might be used depending on the setting
require "modules/BWA.pm";
require "modules/QualityCheck.pm";
require "modules/SamTools.pm";

# config
# default parameters	
my $index_method 	= "is";			# [is, bwasw]
my $bwa_log		= "bwa.log";		# log name
my $quality_check	= 1;			# 1: do quality check
my $os			= "linux";		# [linux, windows]
my $snp_calling		= 1;			# 1: compile to BAM, then find SNP
my $bwa_location	= 0;			# bwa location (Windows use : --bwa_location )
my $samtools_location	= 0;			# samtools location (Windows use : --samtools_location )

# deleties
my $group_size		= 300;			# search deleties group size
my $min_cut_off		= 3;			# min_cut_off for deleties (log, avg)
my $max_cut_off		= 8;			# max_cut_off for deleties (log, avg)
	
# inserties
my $read_length		= 50;			# depends on the sequencing system. length of the reads
my $peak_treshold	= 10;			# under this value there is no peak detected (unmapped - mapped)
my $search_limit	= 500;			# every 500 positions a peak check (local max)
my $max_dist		= 1000;			# max distance between a forward & reverse peak

# input files
my $first_file		= 0;			# first FastQ file
my $second_file		= 0;			# second FastQ file
my $ref_file		= 0;			# reference multi-fasta file
my $sam_file		= 0;			# SAM file

# draw
my $draw_images		= 1;			# 1 : visualise results (using R) 
my $draw_insertion_size	= 10000;		# amount of positions to draw per plot 
my $draw_deletion_size	= 10000;		# amount of positions to draw per plot
my $draw_y_top		= 7;			# standardize plot y-max (if larger will be raised automaticly)

# get paramets from console line
# all these are optional
# GetOptions
	# name= (must)
	# name: (optional)
	# i 	(integer)
	# f	(float)
	# s	(string)
	# !	(negatief, --foo kan dan --nofoo of --no-foo
	# + 	(increase, --more --more --more ==> +3)
	
GetOptions(		
			'index_method=s' 	=> \$index_method, 
			'quality_check!'	=> \$quality_check,
			'snp_calling!'		=> \$snp_calling,
			'os=s'			=> \$os,
			'group_size=i'		=> \$group_size,
			'min_cut_off=i'		=> \$min_cut_off,
			'max_cut_off=i'		=> \$max_cut_off,
			'read_length=i'		=> \$read_length,
			'peak_treshold=i'	=> \$peak_treshold,
			'search_limit=i'	=> \$search_limit,
			'max_dist=i'		=> \$max_dist,
			'first_file=s'		=> \$first_file,
			'second_file=s'		=> \$second_file,
			'ref_file=s'		=> \$ref_file,
			'sam_file=s'		=> \$sam_file,
			'draw_images!'		=> \$draw_images,
			'draw_insertion_size=i'	=> \$draw_insertion_size,
			'draw_deletion_size=i'	=> \$draw_deletion_size,
			'draw_y_top=i'		=> \$draw_y_top,
			'bwa=s'			=> \$bwa_location,
			'samtools=s'		=> \$samtools_location
		);

# start of script
Screen::show_done("Pre-process", $os);

	# make directory's
	mkdir "result";
	mkdir "log";
	mkdir "r_data";
	Log::make_entry("directory\'s made");
	
	if ($sam_file eq 0)
	{
		# default aligner is bwa
		# so if no location is given we need to get it
		if ($bwa_location == 0)
		{
			$bwa_location = PipeLine::Config::command_exist("bwa", 1)
		}

		if ($samtools_location == 0 && $snp_calling)
		{
			$samtools_location = PipeLine::Config::command_exist("samtools", 1)
		}
	
		# no files given, ask for fastQ files
		if ($first_file eq 0 || $second_file eq 0 || $ref_file eq 0)
		{	
			# getting the files & locations
			print "\t# Where can I find the first sequence file ? \n\t";
			$first_file 		= <STDIN>;

			print "\t# Where can I find the second sequence file ? \n\t";
			$second_file 		= <STDIN>;

			print "\t# Where can I find the reference sequence file ? \n\t";
			$ref_file 		= <STDIN>;
	
			chomp($first_file, $second_file, $ref_file);
		}
	
		# unzipping should it be needed
		$first_file 	= GunZip::is_gunzip($first_file);
		$second_file 	= GunZip::is_gunzip($second_file);
		$ref_file 	= GunZip::is_gunzip($ref_file);
		Log::make_entry("files are ready");
		
		# quality check
		if ($quality_check)
		{
			QualityCheck::check_quality($first_file);
			QualityCheck::check_quality($second_file);
			Log::make_entry("checked quality");
		}
		
		# do BWA (makes SAM file)
		Screen::show_done("Alignment", $os);
		Align::BWA::do_bwa($index_method, $ref_file, $first_file, $second_file, $bwa_log);

		$sam_file = "seq.sam";
	}
	else
	{
		Screen::show_done("Alignment -- not_done", $os);
	}

	if ($snp_calling)
	{
		Screen::show_done("SNP calling", $os);
		SamTools::snp_calling($ref_file, $sam_file, $bwa_log);
	}
	else
	{
		Screen::show_done("SNP calling -- not_done", $os);
	}

Screen::show_done("split data", $os);
	SplitData::split_sam($sam_file);		
		
Screen::show_done("processing SAM file", $os);
	PipeLine::process_sam($read_length);
		
Screen::show_done("finding deleties", $os);
	# we use bash sorting to sort
	# windows won't be able to this *sorry*
	PipeLine::sort_isize();
		
	# find deleties
	PipeLine::find_deleties($group_size, $min_cut_off, $max_cut_off);
			
Screen::show_done("finding inserties", $os);
		# find inserties
		PipeLine::find_inserties($peak_treshold, $search_limit, $max_dist);
		
if ($draw_images == 1)
{
	Screen::show_done("making images", $os);

			print "	## generating images ... (insertions)\n";
			# script img_size treshold
			print `Rscript script/draw_inserts_peak.r $draw_insertion_size $peak_treshold`;
	
			print "	## generating images ... (deletions)\n";
			# script limit y_top treshold
			print `Rscript script/draw_deleties_loop.r $draw_deletion_size $draw_y_top $min_cut_off`;
}	
