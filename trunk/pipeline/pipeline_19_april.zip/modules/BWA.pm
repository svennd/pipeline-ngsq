# bwa.pm
# svenn dhert @ sckcen
#
# use :
# use BWA to make a SAM file

package Align::BWA;

use strict;
use warnings;

# for logging
require "modules/Log.pm";

our $VERSION = '1.00';
our @EXPORT  = qw(do_bwa);

sub do_bwa
{
	my @para 	= @_;
	my $index_method= $para['0'];
	my $ref_file	= $para['1'];
	my $first_file	= $para['2'];
	my $second_file	= $para['3'];
	my $log		= $para['4'];
	my $insert_length = $para['5'];
	my $bwa_location	= $para['6'];
	
	my $bwa = $bwa_location;
	if ($bwa_location eq -1)
	{
		$bwa = "bwa";
	}
	chomp($bwa);
	
	# index ref
	print `$bwa index -a $index_method $ref_file >log/$log 2>&1`;
	Log::make_entry("index for reference file made");

	# align 
	print `$bwa aln $ref_file $first_file 1> $first_file.sai 2>log/$log`;
	Log::make_entry("parsed first sequence file");

	print `$bwa aln $ref_file $second_file 1> $second_file.sai 2>log/$log`;
	Log::make_entry("parsed second sequence file");

	# sampe
	if ($insert_length != 0)
	{
		print `$bwa sampe -a $insert_length $ref_file $first_file.sai $second_file.sai $first_file $second_file 1>seq.sam 2>log/$log`;
	}
	else
	{
		print `$bwa sampe $ref_file $first_file.sai $second_file.sai $first_file $second_file 1>seq.sam 2>log/$log`;	
	}	
	Log::make_entry("made SAM file");
}

