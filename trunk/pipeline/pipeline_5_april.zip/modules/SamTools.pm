# SamTools.pm
# svenn dhert @ sckcen
#
# use :
# use BWA to make a SAM file

package SamTools;

use strict;
use warnings;

# for logging
require "modules/Log.pm";

our $VERSION = '1.00';
our @EXPORT  = qw(samtools_snp);

sub snp_calling
{
	my @para 	= @_;
	my $ref_file	= $para['0'];
	my $sam_file	= $para['1'];
	my $log		= $para['2'];

	print `samtools view -uS $sam_file 2>log/$log | samtools sort - seq 2>log/$log`;
	Log::make_entry("made BAM file");

	print `samtools pileup -vcf $ref_file seq.bam >raw.pileup 2>log/$log`;
	Log::make_entry("basic SNP calling done using samtools");

	filter_snp();
	Log::make_entry("filtered & ouput generated for SNPs");
	# index alignment
	#print "\t# index alignment \n";
	#print `samtools faidx $ref_file 2>log/$bwa_log`;
	#print `samtools index seq.bam 2>log/$bwa_log`;
	#Log::make_entry("index alignment");
}

sub filter_snp
{
	# open the required files
	open(PILEUP_SHIFT, "raw.pileup") or die("read error cannot find pileup file");
	open(INDEL, 	">>result/indel.pileup") or die("trying :-).");
	open(SNP_HIGH, 	">>result/high.snp") or die("trying :-).");
	open(SNP_LOW, 	">>result/low.snp") or die("trying :-).");

	my $total_snp;
	my $total_indel;

	while(<PILEUP_SHIFT>)
	{
		# store line
		my $current_line = $_;
	
		(my $rname, my $pos, my $rbase, my $nbase, my $int1, my $int2, my $int3, my $int4, my $coverage, my $phred) = split("\t", $current_line);
	
		# not a snp :(
		if ($rbase eq "*")
		{
			print INDEL $current_line;
			$total_indel++;
		}
		# snp ! :)
		else
		{
			my @coverage 	= split(//, $coverage);
			my $trust 	= 0;
			my $no_trust	= 0;
			#print $coverage . " \n";
			foreach my $info (@coverage)
			{
				# ref
				if ($info eq "." || $info eq ",")
				{
					$no_trust++;
				}
				# snp
				elsif ($info eq "a" || $info eq "t" || $info eq "c" || $info eq "g" || $info eq "A" || $info eq "T" || $info eq "C" || $info eq "G" )
				{
					$trust++;
				}
				else
				{
					# some info is not used
					# $ ^ [^ ... maybe later
					#print $info;
				}
			}
		
			my $trust_calculation = (($no_trust+$trust) > 0) ? floor($trust/($no_trust+$trust)*100) : 0;

			if ($trust_calculation > 95)
			{
				print SNP_HIGH $rname. "\t" . $pos ."\t". $rbase . "\t". $nbase . "\t" . $trust_calculation . "\t" . ($no_trust+$trust) . "\n";
				$total_snp++;
			}
			elsif ($trust_calculation > 60)
			{
				print SNP_LOW $rname. "\t" . $pos ."\t". $rbase . "\t". $nbase . "\t" . $trust_calculation . "\t" . ($no_trust+$trust) . "\n";
			}
		}
	}
		print "total snp : ". $total_snp . " total indel : ". $total_indel . "\n";
		Log::make_entry("Total SNP : " . $total_snp, "log/result.txt");
		Log::make_entry("Total Indel : " . $total_indel, "log/result.txt");

	close(PILEUP_SHIFT);
	close(INDEL);
	close(SNP_HIGH);
	close(SNP_LOW);
}

