# Configure.pm
# svenn dhert @ sckcen

# use
	# will check & config 
	# tools we use
	# @@ NOTE : 	This will not work on windows, an alternative is available
	# @@ 		using File::Which

package PipeLine::Config;

use strict;
use warnings;
 
our $VERSION = '1.00';
our @EXPORT  = qw(command_exist);

sub command_exist
{
	my @para	= @_;
	my $command	= $para[0];
	my $location	= $para[1];
	my $die		= $para[2];

	my $new_location =`which $location$command`;

	if ($die eq 1)
	{
		die "No $command command available, if you have the location please give it using --${command}_location YOUR/LOCATION\n" unless ( $location );
	}
	return $new_location;
}
